package com.screening.testCases;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Iterator;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.screening.utilities.ActionEngine;
import com.screening.utilities.ExcelService;
import com.screening.utilities.ReadConfig;

import io.github.bonigarcia.wdm.WebDriverManager;
import lombok.SneakyThrows;


public class BaseClass extends ActionEngine {

    ReadConfig readconfig = new ReadConfig();

    public String baseURL = readconfig.getApplicationURL();
    public String execution = readconfig.getExecutionType();
    
    public static ApplicationContext context = null;

	public static ApplicationContext getContext() {
		return context;
	}


    public static WebDriver driver;
    public static Logger logger;    
    
	@BeforeSuite(alwaysRun = true)
	
	public void beforeSuite() {
		context = new ClassPathXmlApplicationContext("/env/spring-beans.xml");

	}
	
    @SneakyThrows
    @Parameters("browsers")
    @BeforeMethod
    public void setup(String browser) throws MalformedURLException {
        logger = Logger.getLogger("Work Fussion");
        PropertyConfigurator.configure("Log4j.properties");


        if (execution.equalsIgnoreCase("parallel")) {
            DesiredCapabilities caps = new DesiredCapabilities();

            caps.setCapability("os", "Windows");
            caps.setCapability("os_version", "10");
            caps.setCapability("build", "Work Fussion");
            caps.setCapability("name", "Work Fussion");


            switch (browser) {
                case "chrome":
                	
                    WebDriverManager.chromedriver().setup();
                    caps.setCapability("browser", "chrome");
                    DriverFactory.getInstance().setDriver(driver);
                    break;
                case "firefox":
                    WebDriverManager.firefoxdriver().setup();
                    caps.setCapability("browser", "firefox");
                    break;
                case "ie":
                    WebDriverManager.iedriver().arch32().setup();
                    caps.setCapability("browser", "ie");
                    break;
                case "edgeIE":
                    System.setProperty("webdriver.ie.driver", "C:\\Users\\ssahoo2\\Downloads\\IEDriverServer_Win32_4.0.0\\IEDriverServer.exe");
                    InternetExplorerOptions ieOptions = new InternetExplorerOptions();
                    ieOptions.attachToEdgeChrome();
                    ieOptions.withEdgeExecutablePath("C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe");

                    driver = new InternetExplorerDriver(ieOptions);
                    break;
                case "edge":

                    WebDriverManager.edgedriver().setup();
                    caps.setCapability("browser", "edge");
                    break;
            }
            driver = new RemoteWebDriver(new URL(baseURL), caps);
        } else {

            switch (browser) {
                case "chrome":
                    WebDriverManager.chromedriver().setup();
                    driver = new ChromeDriver();
                    DriverFactory.getInstance().setDriver(driver);
                    break;
                case "firefox":
                    WebDriverManager.firefoxdriver().setup();
                    driver = new FirefoxDriver();
                    DriverFactory.getInstance().setDriver(driver);
                    break;
                case "ie":
                    WebDriverManager.iedriver().arch32().setup();
                    driver = new InternetExplorerDriver();
                    DriverFactory.getInstance().setDriver(driver);
                    break;
                case "edgeIE":
                    System.setProperty("webdriver.ie.driver", "Drivers/IEDriverServer.exe");
                    InternetExplorerOptions ieOptions = new InternetExplorerOptions();
                    ieOptions.attachToEdgeChrome();
                    ieOptions.withEdgeExecutablePath("C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe");

                    driver = new InternetExplorerDriver(ieOptions);
                    DriverFactory.getInstance().setDriver(driver);
                    break;
                case "edge":
                    WebDriverManager.edgedriver().setup();
                    driver = new EdgeDriver();
                    DriverFactory.getInstance().setDriver(driver);
                    break;
            }

        }

        DriverFactory.getInstance().getDriver().get(baseURL);
        DriverFactory.getInstance().getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        DriverFactory.getInstance().getDriver().manage().window().maximize();
        try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


    }


	@AfterMethod
	public void tearDown()
	{
		DriverFactory.getInstance().getDriver().quit();
	}

    public void captureScreen1(WebDriver driver, String tname) throws IOException {
        TakesScreenshot ts = (TakesScreenshot) driver;
        File source = ts.getScreenshotAs(OutputType.FILE);
        File target = new File(System.getProperty("user.dir") + "/Screenshots/" + tname + ".png");
        FileUtils.copyFile(source, target);
        System.out.println("Screenshot taken");
    }

    
	@DataProvider(name = "ScreeninDataProvider")
	public Iterator<Object[]> ScreeninDataProvider(Method method) {

			
		return new ExcelService().readTestDataFromExcel(
				(String) BaseClass.context.getBean("ScreeningTestDataWorkBookName"), "TestData", method.getName());

	}


}
