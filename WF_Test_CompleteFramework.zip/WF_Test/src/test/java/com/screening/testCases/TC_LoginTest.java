package com.screening.testCases;


import java.util.Map;

import org.testng.annotations.Test;

import com.screening.pageObjects.LoginPage;




public class TC_LoginTest extends BaseClass {

	// Verify loginTestSuccess-  Status: user Sachin Tendulkar was created
    @Test(dataProvider = "ScreeninDataProvider")
    public void loginTestSuccess(Map<String, String> data) throws Throwable {
    
        LoginPage lp = new LoginPage(driver);
        lp.login(data.get("username"), data.get("fullName"), data.get("password"));
        

        String expectedStatusMessage = "Status: user "+data.get("username")+" was created";
 
		lp.verifyStatusMessage(expectedStatusMessage);

    }
    
    // Verify loginUserEmpty -  Status: Login cannot be empty
    @Test(dataProvider = "ScreeninDataProvider")
    public void loginUserEmpty(Map<String, String> data) throws Throwable {
    
        LoginPage lp = new LoginPage(driver);
        lp.login("", data.get("fullName"), data.get("password"));
        

        String expectedStatusMessage = "Status: Login cannot be empty";
 
		lp.verifyStatusMessage(expectedStatusMessage);

    }
    
    //Verify loginFullNameEmpty - Status: Full name cannot be empty
    @Test(dataProvider = "ScreeninDataProvider")
    public void loginFullNameEmpty(Map<String, String> data) throws Throwable {
    
        LoginPage lp = new LoginPage(driver);
        lp.login(data.get("username"), "", data.get("password"));
        

        String expectedStatusMessage = "Status: Full name cannot be empty";
 
		lp.verifyStatusMessage(expectedStatusMessage);

    }
    
    // Verify loginPasswordEmpty - Status: Password cannot be empty
    @Test(dataProvider = "ScreeninDataProvider")
    public void loginPasswordEmpty(Map<String, String> data) throws Throwable {
    
        LoginPage lp = new LoginPage(driver);
        lp.login(data.get("username"), data.get("fullName"), "");
        

        String expectedStatusMessage = "Status: Password cannot be empty";
 
		lp.verifyStatusMessage(expectedStatusMessage);

    }
    
    // Verify loginPasswordWeak - Status: Password does not conform rules
    @Test(dataProvider = "ScreeninDataProvider")
    public void loginPasswordWeak(Map<String, String> data) throws Throwable {
    
        LoginPage lp = new LoginPage(driver);
        lp.login(data.get("username"), data.get("fullName"), data.get("password"));
        

        String expectedStatusMessage = "Status: Password does not conform rules";
 
		lp.verifyStatusMessage(expectedStatusMessage);

    }
    
    
    
    // Verify falseFailTest with wrong message to get fail test case
    @Test(dataProvider = "ScreeninDataProvider")
    public void falseFailTest(Map<String, String> data) throws Throwable {
    
        LoginPage lp = new LoginPage(driver);
        lp.login(data.get("username"), data.get("fullName"), data.get("password"));
        

        String expectedStatusMessage = "Status: Wrong Message to fail test case";
 
		lp.verifyStatusMessage(expectedStatusMessage);

    }
    

}
