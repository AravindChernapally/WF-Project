package com.screening.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.screening.testCases.BaseClass;
import com.screening.testCases.DriverFactory;



public class LoginPage extends BaseClass{

    WebDriver ldriver;

    public LoginPage(WebDriver rdriver) {
        ldriver = DriverFactory.getInstance().getDriver();
        PageFactory.initElements(rdriver, this);
    }
    
    @FindBy(id = "username")
    WebElement txtUserName;
    
    @FindBy(id = "name")
    WebElement txtFullName;
    
    @FindBy(id = "password")
    WebElement txtPassword;
    
    @FindBy(id = "submit")
    WebElement submit;
    
    @FindBy(id = "status")
    WebElement status;

    // Login
    public void login(String userName, String fullName, String password) {
    	
    	  sendKeys_custom(txtUserName, "User Name", userName);
    	  sendKeys_custom(txtFullName, "Full Name", fullName);
    	  sendKeys_custom(txtPassword, "Password", password);    	 
    	  click_custom(submit, "Submit"); 
 
    }
    
    // Verify login status message
    public void verifyStatusMessage(String expectedStatusMessage) throws Throwable {
    	String actualStatusMessage=  getText_custom(status, "get Status Message");
    	assertEqualsString_custom(expectedStatusMessage, actualStatusMessage, "Status Message");
    }
  
}









